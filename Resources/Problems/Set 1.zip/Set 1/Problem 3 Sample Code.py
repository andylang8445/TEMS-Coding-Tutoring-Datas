a = input()
b = input()
print(a+b)
print(int(a)+int(b))