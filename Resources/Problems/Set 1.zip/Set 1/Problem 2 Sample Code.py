a = input()
b = input()
print(a+"+"+b)