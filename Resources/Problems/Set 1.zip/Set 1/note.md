# Set 1
## Simple IO
* Problem 1
## Use of variables
### Storing values
* Problem 2
### Using variables for operations
* problem 3