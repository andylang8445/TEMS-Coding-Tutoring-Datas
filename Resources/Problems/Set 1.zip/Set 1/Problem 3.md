# Set 1
## Problem 3
Create a code that gets two lines of integer input and combine those two inputs as well as summation


<b>Sample input:</b><br>
<i>
1234<br>5
</i>
<br>
<b>Sample output:</b><br>
<i>
12345<br>1239
</i>
