# Set 1
## Problem 1
Write a code where it repeats the input that user have inputted before the enter (return) was inputted