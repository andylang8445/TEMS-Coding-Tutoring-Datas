# Set 1
## Problem 2
Create a code that gets two lines of input and combine those two inputs using '+' character


<b>Sample input:</b><br>
<i>
abcd<br>ggio
</i>
<br>
<b>Sample output:</b><br>
<i>
abcd+ggio
</i>
