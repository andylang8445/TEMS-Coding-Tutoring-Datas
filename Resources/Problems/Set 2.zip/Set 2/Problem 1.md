# Set 2
## Problem 1
Create a code that determines if a given integer is odd or even.<br>For this example, consider 0 as even number

### Sample Case 1
<b>Sample input:</b><br>
<i>
13
</i>
<br>
<b>Sample output:</b><br>
<i>
odd
</i>
### Sample Case 2
<b>Sample input:</b><br>
<i>
0
</i>
<br>
<b>Sample output:</b><br>
<i>
even
</i>
