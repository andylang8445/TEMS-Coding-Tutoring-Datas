# Set 2
## Problem 5
Write the code that prints all multiples of the given number between 0 and 200. (Consider 0 to only be the multiple of 0 and assume all inputs are 0 or positive integer. If there is no multiple of given number in the range, print DNE instead of printing nothing)


<b>Sample input 1:</b><br>
<i>
0
</i>
<br>
<b>Sample output 1:</b><br>
<i>
0
</i>

<b>Sample input 2:</b><br>
<i>
300
</i>
<br>
<b>Sample output 2:</b><br>
<i>
DNE
</i>

<b>Sample input 3:</b><br>
<i>
50
</i>
<br>
<b>Sample output 3:</b><br>
<i>
50<br>100<br>150<br>200
</i>
