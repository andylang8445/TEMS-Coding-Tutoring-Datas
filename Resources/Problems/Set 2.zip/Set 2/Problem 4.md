# Set 2
## Problem 4
Create a code where you get the set of numbers and search each item untill -1 is queried. If the quried item exists in the given set, print 'exists' and 'DNE' in other cases.
<br><b>Note: You are not allowed to use 'in' operation to look if an item exists in the set</b>


<b>Sample input:</b><br>
<i>
1 2 3 4 45 99 0 -232 34<br>5<br>99<br>-1
</i>
<br>
<b>Sample output:</b><br>
<i>
DNE<br>exists
</i>
