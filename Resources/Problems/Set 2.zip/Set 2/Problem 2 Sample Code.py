given = input()
if len(given) == 0 or ("abba" in given):
    print("ab-string")
else:
    print("not an ab-string")