# Set 2
## Problem 3
Create a code where it adds all numbers inputted untill string 'zzz' is inputted and print the sum after the input of 'zzz'.


<b>Sample input:</b><br>
<i>
1<br>5<br>4<br>9<br>zzz
</i>
<br>
<b>Sample output:</b><br>
<i>
19<br>
</i>
