if int(input()) % 2 == 0:
    print("even")
else:
    print("odd")
