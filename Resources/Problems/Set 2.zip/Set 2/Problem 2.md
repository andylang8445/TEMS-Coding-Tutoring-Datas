# Set 2
## Problem 2
Consider the following:
Let the name ab-string represent the string including "abba" in it.<br> If the number of appearing of "abba" pattern does not matter, create a code determining if a given string is an ab-string.


### Sample Case 1
<b>Sample input:</b><br>
<i>
abbastrg
</i>
<br>
<b>Sample output:</b><br>
<i>
ab-string
</i>
### Sample Case 2
<b>Sample input:</b><br>
<i>
abbbbba
</i>
<br>
<b>Sample output:</b><br>
<i>
not an ab-string
</i>

### Sample Case 2
<b>Sample input:</b><br>
<i>

</i>
<br>
<b>Sample output:</b><br>
<i>
ab-string
</i>
<p>for this problem, consider an empty string as an ab-string
